package com.study.springboot202210haehyuk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot202210HaehyukApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot202210HaehyukApplication.class, args);
	}

}
