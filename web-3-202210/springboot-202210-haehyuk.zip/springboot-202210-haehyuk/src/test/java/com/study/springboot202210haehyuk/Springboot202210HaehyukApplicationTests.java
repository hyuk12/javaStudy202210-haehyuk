package com.study.springboot202210haehyuk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot202210HaehyukApplicationTests {

	@Test
	void contextLoads() {
	}

}
